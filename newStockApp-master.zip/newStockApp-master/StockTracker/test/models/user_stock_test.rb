require 'test_helper'

class UserStockTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
